<?php

// Bootstrap the application from the public folder so users can visit
// http://localhost/CodeIgniter/ without needing to include /public in the URL.

require __DIR__ . '/public/index.php';
